# features/steps/employee_search_steps.py
from behave import when, then
from pages.employee_list_page import EmployeeListPage

@when('I search for employee "{first}" "{last}"')
def step_search_employee(context, first, last):
    context.emp_list = EmployeeListPage(context.driver)
    context.emp_list.search_employee(f"{first} {last}")

@then('the employee should appear in results')
def step_verify_result(context):
    # We just added John Doe or Alice Smith → wait a bit for indexing
    import time
    time.sleep(3)
    assert context.emp_list.is_employee_present("John", "Doe") or \
           context.emp_list.is_employee_present("Alice", "Smith")