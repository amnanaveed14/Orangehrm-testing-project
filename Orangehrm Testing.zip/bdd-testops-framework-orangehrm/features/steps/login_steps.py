from behave import given, when, then
from pages.login_page import LoginPage
from pages.dashboard_page import DashboardPage
from utils.data_loader import DataLoader

@given('I am on OrangeHRM login page')
def step_impl(context):
    context.login_page = LoginPage(context.driver)
    context.login_page.open()

@when('I login with valid credentials')
def step_impl(context):
    username, password = DataLoader.from_redis()
    context.login_page.login(username, password)
    context.dashboard = DashboardPage(context.driver)

@when('I login with username "{user}" and password "{pwd"')
def step_impl(context, user, pwd):
    context.login_page.login(user, pwd)

@then('I should see the dashboard')
def step_impl(context):
    assert "dashboard" in context.driver.current_url

@then('I should see error "{msg}"')
def step_impl(context, msg):
    assert msg in context.login_page.get_error_message()