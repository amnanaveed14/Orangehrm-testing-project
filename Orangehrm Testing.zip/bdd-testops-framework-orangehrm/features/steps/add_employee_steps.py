# features/steps/add_employee_steps.py
from behave import when, then
from pages.pim_page import PIMPage

@when('I navigate to Add Employee page')
def step_navigate_add_employee(context):
    context.dashboard.go_to_add_employee()
    context.pim_page = PIMPage(context.driver)

@when('I fill first name "{first}", last name "{last}", employee id "{emp_id}"')
def step_fill_employee(context, first, last, emp_id):
    context.pim_page.fill_employee_details(first, last, emp_id or "")

@when('I save the employee')
def step_save(context):
    context.pim_page.save_employee()

@then('I should see success message containing "{text}"')
def step_check_success(context, text):
    msg = context.pim_page.get_success_message()
    assert text in msg, f"Expected '{text}' but got '{msg}'"