# utils/hooks.py
import allure
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.core.os_manager import ChromeType

def before_all(context):
    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")
    options.add_argument("--disable-notifications")
    options.add_argument("--disable-infobars")
    options.add_experimental_option("useAutomationExtension", False)
    options.add_experimental_option("excludeSwitches", ["enable-automation"])

    context.driver = webdriver.Chrome(
        ChromeDriverManager(chrome_type=ChromeType.GOOGLE).install(),
        options=options
    )
    context.driver.implicitly_wait(10)

def after_all(context):
    if hasattr(context, "driver"):
        context.driver.quit()

def before_scenario(context, scenario):
    pass

def after_scenario(context, scenario):
    if scenario.status == "failed":
        allure.attach(
            context.driver.get_screenshot_as_png(),
            name="screenshot",
            attachment_type=allure.attachment_type.PNG
        )