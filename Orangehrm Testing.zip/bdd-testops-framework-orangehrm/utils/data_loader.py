# utils/data_loader.py
import openpyxl
import redis
import os

class DataLoader:
    @staticmethod
    def from_redis(key="orangehrm:admin"):
        try:
            r = redis.Redis(host='localhost', port=6379, db=0, decode_responses=True)
            pwd = r.get(key)
            return "Admin", pwd or "admin123"
        except:
            return "Admin", "admin123"   # fallback if Redis not running

    @staticmethod
    def from_excel():
        wb = openpyxl.load_workbook("data/employees.xlsx")
        sheet = wb.active
        data = []
        for row in sheet.iter_rows(min_row=2, values_only=True):
            data.append({"first": row[0], "last": row[1], "id": str(row[2] or "")})
        return data