from selenium.webdriver.common.by import By
from .base_page import BasePage

class EmployeeListPage(BasePage):
    PIM_MENU = (By.XPATH, "//span[normalize-space()='PIM']")
    SEARCH_NAME = (By.XPATH, "(//input[@placeholder='Type for hints...'])[1]")
    SEARCH_BTN = (By.CSS_SELECTOR, "button[type='submit']")
    RESULT_ROW = (By.CSS_SELECTOR, ".oxd-table-card")

    def search_employee(self, name):
        self.click(self.PIM_MENU)
        self.type_text(self.SEARCH_NAME, name)
        self.click(self.SEARCH_BTN)
        self.wait.until(EC.presence_of_all_elements_located(self.RESULT_ROW))

    def is_employee_present(self, first_name, last_name):
        rows = self.driver.find_elements(*self.RESULT_ROW)
        for row in rows:
            text = row.text
            if first_name in text and last_name in text:
                return True
        return False