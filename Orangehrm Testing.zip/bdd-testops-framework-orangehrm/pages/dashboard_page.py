from selenium.webdriver.common.by import By
from .base_page import BasePage

class DashboardPage(BasePage):
    PIM_MENU = (By.XPATH, "//span[normalize-space()='PIM']")
    ADD_EMPLOYEE = (By.XPATH, "//a[normalize-space()='Add Employee']")

    def go_to_add_employee(self):
        self.click(self.PIM_MENU)
        self.click(self.ADD_EMPLOYEE)