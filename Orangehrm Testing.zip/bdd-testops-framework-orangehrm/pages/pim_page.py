from selenium.webdriver.common.by import By
from .base_page import BasePage

class PIMPage(BasePage):
    FIRST_NAME = (By.NAME, "firstName")
    LAST_NAME = (By.NAME, "lastName")
    EMPLOYEE_ID = (By.XPATH, "(//input[@class='oxd-input oxd-input--active'])[2]")
    SAVE_BTN = (By.CSS_SELECTOR, "button[type='submit']")
    SUCCESS_TOAST = (By.CSS_SELECTOR, ".oxd-text--toast-message")

    def fill_employee_details(self, first, last, emp_id=""):
        self.type_text(self.FIRST_NAME, first)
        self.type_text(self.LAST_NAME, last)
        if emp_id:
            self.find(self.EMPLOYEE_ID).clear()
            self.type_text(self.EMPLOYEE_ID, emp_id)

    def save_employee(self):
        self.click(self.SAVE_BTN)

    def get_success_message(self):
        return self.find(self.SUCCESS_TOAST).text