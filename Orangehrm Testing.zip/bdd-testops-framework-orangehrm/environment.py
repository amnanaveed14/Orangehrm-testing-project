# environment.py
from utils.hooks import before_all, after_all, before_scenario, after_scenario

def before_all(context):
    before_all(context)

def after_all(context):
    after_all(context)

def before_scenario(context, scenario):
    before_scenario(context, scenario)

def after_scenario(context, scenario):
    after_scenario(context, scenario)